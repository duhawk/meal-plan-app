// Meal_plan/Frontend/src/App.jsx
import AppRouter from './routes';

export default function App() { return <AppRouter />; }


